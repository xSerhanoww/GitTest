﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DBConnect.Data.Models
{
    public class ProductNote
    {
        [Key]
        [Comment("Note Indentifier")]
        public Guid Id { get; set; }
        [Required]
        [Comment("Note Content")]
        public string Content { get; set; } = string.Empty;
        [Required]
        [Comment("Product Indentifier")]
        public int ProductId { get; set; }
        [ForeignKey(nameof(ProductId))]
        public Product Product { get; set; } = null!;

    }
}
